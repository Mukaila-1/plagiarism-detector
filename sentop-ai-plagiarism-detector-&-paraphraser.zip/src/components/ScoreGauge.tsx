import React from 'react';

interface ScoreGaugeProps {
  score: number;
}

const ScoreGauge: React.FC<ScoreGaugeProps> = ({ score }) => {
  const radius = 60;
  const stroke = 12;
  const normalizedRadius = radius - stroke * 2;
  const circumference = normalizedRadius * 2 * Math.PI;
  const strokeDashoffset = circumference - (score / 100) * circumference;

  let colorClass = 'text-green-500';
  if (score > 30) colorClass = 'text-yellow-500';
  if (score > 60) colorClass = 'text-red-500';
  
  let strokeColorClass = 'stroke-green-500';
  if (score > 30) strokeColorClass = 'stroke-yellow-500';
  if (score > 60) strokeColorClass = 'stroke-red-500';

  return (
    <div className="relative inline-flex items-center justify-center">
      <svg
        height={radius * 2}
        width={radius * 2}
        className="-rotate-90"
      >
        <circle
          className="text-gray-200"
          strokeWidth={stroke}
          stroke="currentColor"
          fill="transparent"
          r={normalizedRadius}
          cx={radius}
          cy={radius}
        />
        <circle
          className={`${strokeColorClass} transition-all duration-1000 ease-in-out`}
          strokeWidth={stroke}
          strokeDasharray={`${circumference} ${circumference}`}
          style={{ strokeDashoffset }}
          stroke="currentColor"
          fill="transparent"
          r={normalizedRadius}
          cx={radius}
          cy={radius}
          strokeLinecap="round"
        />
      </svg>
      <span className={`absolute text-4xl font-bold ${colorClass}`}>
        {score}
        <span className="text-2xl">%</span>
      </span>
    </div>
  );
};

export default ScoreGauge;
