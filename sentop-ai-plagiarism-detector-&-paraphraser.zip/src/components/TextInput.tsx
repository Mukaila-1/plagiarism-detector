import React from 'react';
import ClipboardIcon from './icons/ClipboardIcon';
import DocumentIcon from './icons/DocumentIcon';

interface TextInputProps {
  label: string;
  placeholder: string;
  value: string;
  onValueChange: (value: string) => void;
  id: string;
  wordLimit: number;
}

const TextInput: React.FC<TextInputProps> = ({ label, placeholder, value, onValueChange, id, wordLimit }) => {
  
  const handlePaste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      onValueChange(text);
    } catch (err) {
      console.error('Failed to read clipboard contents: ', err);
      // Fallback for older browsers could be implemented here if needed
    }
  };

  const wordCount = React.useMemo(() => {
    if (!value.trim()) return 0;
    return value.trim().split(/\s+/).filter(Boolean).length;
  }, [value]);

  const isOverLimit = wordCount > wordLimit;

  return (
    <div className="bg-white/5 ring-1 ring-white/10 rounded-xl shadow-lg p-6 backdrop-blur-md">
      <div className="flex justify-between items-center mb-4">
        <label htmlFor={id} className="flex items-center text-lg font-semibold text-white">
          <DocumentIcon className="w-6 h-6 mr-2 text-brand-lightblue" />
          {label}
        </label>
        <button
          onClick={handlePaste}
          className="flex items-center px-3 py-1.5 text-sm font-semibold text-white bg-white/10 rounded-md hover:bg-white/20 transition-colors"
          title="Paste from clipboard"
        >
          <ClipboardIcon className="w-4 h-4 mr-1.5" />
          Paste
        </button>
      </div>
      <textarea
        id={id}
        value={value}
        onChange={(e) => onValueChange(e.target.value)}
        placeholder={placeholder}
        className="w-full h-64 p-4 bg-gray-800/50 text-gray-300 border border-gray-600 rounded-lg resize-y focus:ring-2 focus:ring-brand-lightblue focus:border-brand-lightblue transition-shadow duration-200 placeholder-gray-500"
      />
      <div className="text-right mt-2 text-sm font-medium">
        <span className={isOverLimit ? 'text-red-400' : 'text-gray-400'}>
          {wordCount.toLocaleString()} / {wordLimit.toLocaleString()} words
        </span>
      </div>
    </div>
  );
};

export default TextInput;
