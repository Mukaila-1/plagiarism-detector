import React from 'react';
import type { PlagiarismResult } from '../types';
import ScoreGauge from './ScoreGauge';
import SparklesIcon from './icons/SparklesIcon';
import CopyIcon from './icons/CopyIcon';
import DownloadIcon from './icons/DownloadIcon';

interface ResultCardProps {
  isLoading: boolean;
  result: PlagiarismResult | null;
  error: string | null;
  onParaphrase: () => void;
  isParaphrasing: boolean;
  paraphrasedText: string | null;
  paraphraseError: string | null;
}

interface ResultDisplayProps {
  result: PlagiarismResult;
  onParaphrase: () => void;
  isParaphrasing: boolean;
  paraphrasedText: string | null;
  paraphraseError: string | null;
}


const LoadingState: React.FC = () => (
  <div className="flex flex-col items-center justify-center text-center p-8">
    <div className="animate-pulse-fast">
        <svg className="w-16 h-16 text-brand-blue" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z" />
        </svg>
    </div>
    <h3 className="mt-4 text-xl font-semibold text-gray-800">Analyzing Texts...</h3>
    <p className="mt-2 text-gray-600">Our AI is comparing the documents. This may take a moment.</p>
  </div>
);

const InitialState: React.FC = () => (
  <div className="flex flex-col items-center justify-center text-center p-8">
    <svg className="w-16 h-16 text-gray-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 18v-5.25m0 0a6.01 6.01 0 0 0 1.5-.189m-1.5.189a6.01 6.01 0 0 1-1.5-.189m3.75 7.478a12.06 12.06 0 0 1-4.5 0m3.75 2.311a7.5 7.5 0 0 1-7.5 0c-1.255 0-2.443.29-3.5.832m14.5.002c1.057-.542 2.245-.832 3.5-.832a7.5 7.5 0 0 1-7.5 0" />
    </svg>
    <h3 className="mt-4 text-xl font-semibold text-gray-800">Awaiting Analysis</h3>
    <p className="mt-2 text-gray-600">Enter your texts above and click "Check for Plagiarism" to see the results.</p>
  </div>
);

const ErrorState: React.FC<{ message: string }> = ({ message }) => (
  <div className="flex flex-col items-center justify-center text-center p-8 bg-red-50 border border-red-200 rounded-lg">
    <svg className="w-16 h-16 text-red-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126ZM12 15.75h.007v.008H12v-.008Z" />
    </svg>
    <h3 className="mt-4 text-xl font-semibold text-red-800">An Error Occurred</h3>
    <p className="mt-2 text-red-600">{message}</p>
  </div>
);

const handleDownload = (filename: string, content: string) => {
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};

const ResultDisplay: React.FC<ResultDisplayProps> = ({ result, onParaphrase, isParaphrasing, paraphrasedText, paraphraseError }) => {
    const handleDownloadAnalysis = () => {
        let reportContent = `Plagiarism Analysis Report\n`;
        reportContent += `=========================\n\n`;
        reportContent += `Similarity Score: ${result.score}%\n\n`;
        reportContent += `AI Analysis:\n`;
        reportContent += `-----------\n`;
        reportContent += `${result.analysis}\n\n`;

        if (result.sources && result.sources.length > 0) {
            reportContent += `Detected Sources:\n`;
            reportContent += `---------------\n`;
            result.sources.forEach((source, index) => {
                reportContent += `${index + 1}. ${source.title}\n`;
                reportContent += `   ${source.uri}\n\n`;
            });
        }
        handleDownload('plagiarism_report.txt', reportContent);
    };

    const handleDownloadParaphrased = () => {
        if (!paraphrasedText) return;
        handleDownload('paraphrased_text.txt', paraphrasedText);
    };

    return (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 p-6 w-full">
            <div className="md:col-span-1 flex flex-col items-center justify-center text-center">
                <h3 className="text-xl font-bold text-gray-800 mb-4">Similarity Score</h3>
                <ScoreGauge score={result.score} />
                <p className="mt-4 text-sm text-gray-600">Higher scores indicate more similarity.</p>
            </div>
            <div className="md:col-span-2">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="text-xl font-bold text-gray-800">AI Analysis</h3>
                    <button
                        onClick={handleDownloadAnalysis}
                        className="flex items-center px-3 py-1.5 text-sm font-semibold text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200 transition-colors"
                        title="Download analysis report"
                    >
                        <DownloadIcon className="w-4 h-4 mr-1.5" />
                        Download
                    </button>
                </div>

                <div className="prose prose-blue max-w-none p-4 bg-gray-50 border border-gray-200 rounded-lg text-gray-700 whitespace-pre-wrap mb-6">
                    <p>{result.analysis}</p>
                </div>
                {result.sources && result.sources.length > 0 && (
                    <div>
                        <h3 className="text-xl font-bold text-gray-800 mb-4">Detected Sources</h3>
                        <ul className="space-y-3">
                            {result.sources.map((source, index) => (
                                <li key={index} className="p-3 bg-gray-50 border border-gray-200 rounded-lg">
                                    <a
                                        href={source.uri}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="font-medium text-brand-blue hover:underline break-all"
                                    >
                                        {source.title}
                                    </a>
                                    <p className="text-sm text-gray-500 mt-1 break-all">{source.uri}</p>
                                </li>
                            ))}
                        </ul>
                    </div>
                )}
            </div>
            {result.score > 30 && (
                <div className="md:col-span-3 mt-6 pt-6 border-t border-gray-200">
                    <h3 className="text-xl font-bold text-gray-800 mb-2">Paraphrase Suggestion</h3>
                    <p className="text-gray-600 mb-4 text-sm">
                        The similarity score is high. Use our AI to get a paraphrased version of your "Text to Check" to help you rewrite it.
                    </p>
                    {!paraphrasedText && (
                        <button
                            onClick={onParaphrase}
                            disabled={isParaphrasing}
                            className="inline-flex items-center justify-center px-5 py-2.5 bg-brand-lightblue hover:bg-blue-700 text-white font-bold rounded-lg shadow transition-all duration-300 ease-in-out transform hover:scale-105 disabled:bg-gray-400 disabled:cursor-not-allowed disabled:scale-100"
                        >
                            {isParaphrasing ? (
                            <>
                                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                </svg>
                                Paraphrasing...
                            </>
                            ) : (
                            <>
                                <SparklesIcon className="w-5 h-5 mr-2" />
                                Paraphrase Text
                            </>
                            )}
                        </button>
                    )}
                    {paraphraseError && <div className="mt-4 p-4 bg-red-50 border border-red-200 text-red-700 rounded-lg text-sm">{paraphraseError}</div>}
                    {paraphrasedText && (
                        <div className="mt-4">
                            <div className="prose prose-blue max-w-none p-4 bg-gray-50 border border-gray-200 rounded-lg text-gray-700 relative">
                            <p>{paraphrasedText}</p>
                            <div className="absolute top-2 right-2 flex items-center space-x-2">
                                <button 
                                    onClick={() => navigator.clipboard.writeText(paraphrasedText)} 
                                    className="p-1.5 bg-gray-200 hover:bg-gray-300 rounded-md transition-colors"
                                    title="Copy to clipboard"
                                >
                                    <CopyIcon className="w-5 h-5 text-gray-600" />
                                </button>
                                <button 
                                    onClick={handleDownloadParaphrased}
                                    className="p-1.5 bg-gray-200 hover:bg-gray-300 rounded-md transition-colors"
                                    title="Download paraphrased text"
                                >
                                    <DownloadIcon className="w-5 h-5 text-gray-600" />
                                </button>
                            </div>
                            </div>
                        </div>
                    )}
                </div>
            )}
        </div>
    )
};


const ResultCard: React.FC<ResultCardProps> = ({ isLoading, result, error, onParaphrase, isParaphrasing, paraphrasedText, paraphraseError }) => {
  return (
    <div className="bg-white rounded-xl shadow-lg min-h-[250px] flex items-center justify-center transition-all duration-300">
      {isLoading && <LoadingState />}
      {!isLoading && error && <ErrorState message={error} />}
      {!isLoading && !error && result && (
        <ResultDisplay 
            result={result} 
            onParaphrase={onParaphrase}
            isParaphrasing={isParaphrasing}
            paraphrasedText={paraphrasedText}
            paraphraseError={paraphraseError}
        />
      )}
      {!isLoading && !error && !result && <InitialState />}
    </div>
  );
};

export default ResultCard;
