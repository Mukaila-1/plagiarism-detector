import type { PlagiarismResult } from '../types';

async function analyze(action: 'plagiarism' | 'paraphrase', body: object): Promise<any> {
  const response = await fetch('/api/analyze', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ action, ...body }),
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({ message: 'An unknown server error occurred.' }));
    throw new Error(errorData.message || `Request failed with status ${response.status}`);
  }

  return response.json();
}

export async function checkPlagiarism(textToCheck: string, originalText?: string): Promise<PlagiarismResult> {
  const data = await analyze('plagiarism', { textToCheck, originalText });
  return data as PlagiarismResult;
}

export async function paraphraseText(text: string): Promise<string> {
  const data = await analyze('paraphrase', { text: text });
  return data.paraphrasedText as string;
}
