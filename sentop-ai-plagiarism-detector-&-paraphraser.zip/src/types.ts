export interface Source {
  title: string;
  uri: string;
}

export interface PlagiarismResult {
  score: number;
  analysis: string;
  sources?: Source[];
}
