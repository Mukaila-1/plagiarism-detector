import React, { useState, useCallback } from 'react';
import Header from './components/Header';
import TextInput from './components/TextInput';
import ResultCard from './components/ResultCard';
import { checkPlagiarism, paraphraseText } from './services/geminiService';
import { PlagiarismResult } from './types';
import SparklesIcon from './components/icons/SparklesIcon';

const WORD_LIMIT = 5000;

const App: React.FC = () => {
  const [textToCheck, setTextToCheck] = useState<string>('');
  const [originalText, setOriginalText] = useState<string>('');
  const [result, setResult] = useState<PlagiarismResult | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const [isParaphrasing, setIsParaphrasing] = useState<boolean>(false);
  const [paraphrasedText, setParaphrasedText] = useState<string | null>(null);
  const [paraphraseError, setParaphraseError] = useState<string | null>(null);

  const getWordCount = (text: string) => {
    if (!text.trim()) return 0;
    return text.trim().split(/\s+/).filter(Boolean).length;
  };

  const handleCheckPlagiarism = useCallback(async () => {
    if (!textToCheck.trim()) {
      setError('Please provide the text to check.');
      return;
    }

    const textToCheckWords = getWordCount(textToCheck);
    if (textToCheckWords > WORD_LIMIT) {
      setError(`"Text to Check" exceeds the ${WORD_LIMIT.toLocaleString()} word limit. Please shorten the text.`);
      return;
    }
    
    const originalTextWords = getWordCount(originalText);
    if (originalText.trim() && originalTextWords > WORD_LIMIT) {
      setError(`"Original Text" exceeds the ${WORD_LIMIT.toLocaleString()} word limit. Please shorten the text.`);
      return;
    }

    setIsLoading(true);
    setError(null);
    setResult(null);
    setParaphrasedText(null);
    setParaphraseError(null);

    try {
      const plagiarismResult = await checkPlagiarism(textToCheck, originalText);
      setResult(plagiarismResult);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
    } finally {
      setIsLoading(false);
    }
  }, [textToCheck, originalText]);

  const handleParaphrase = useCallback(async () => {
    if (!textToCheck.trim()) {
      setParaphraseError("There is no text to paraphrase.");
      return;
    }
    setIsParaphrasing(true);
    setParaphraseError(null);
    setParaphrasedText(null);
    try {
      const result = await paraphraseText(textToCheck);
      setParaphrasedText(result);
    } catch (err) {
      setParaphraseError(err instanceof Error ? err.message : 'An unknown error occurred during paraphrasing.');
    } finally {
      setIsParaphrasing(false);
    }
  }, [textToCheck]);

  return (
    <div className="min-h-screen bg-brand-light text-brand-dark font-sans">
      <div className="relative isolate overflow-hidden bg-gray-900">
        <svg
          className="absolute inset-0 -z-10 h-full w-full stroke-white/10 [mask-image:radial-gradient(100%_100%_at_top_right,white,transparent)]"
          aria-hidden="true"
        >
          <defs>
            <pattern
              id="983e3e4c-de6d-4c3f-8d64-b9761d1534cc"
              width={200}
              height={200}
              x="50%"
              y={-1}
              patternUnits="userSpaceOnUse"
            >
              <path d="M.5 200V.5H200" fill="none" />
            </pattern>
          </defs>
          <svg x="50%" y={-1} className="overflow-visible fill-gray-800/20">
            <path
              d="M-200 0h201v201h-201Z M600 0h201v201h-201Z M-400 600h201v201h-201Z M200 800h201v201h-201Z"
              strokeWidth={0}
            />
          </svg>
          <rect width="100%" height="100%" strokeWidth={0} fill="url(#983e3e4c-de6d-4c3f-8d64-b9761d1534cc)" />
        </svg>
        <div className="absolute inset-x-0 top-1/2 -z-10 -translate-y-1/2 transform-gpu overflow-hidden opacity-30 blur-3xl" aria-hidden="true">
            <div className="ml-[max(50%,38rem)] aspect-[1313/771] w-[82.0625rem] bg-gradient-to-tr from-[#3b82f6] to-[#1e40af]" style={{clipPath: 'polygon(74.1% 44.1%, 100% 61.6%, 97.5% 26.9%, 85.5% 0.1%, 80.7% 2%, 72.5% 32.5%, 60.2% 62.4%, 52.4% 68.1%, 47.5% 58.3%, 45.2% 34.5%, 27.5% 76.7%, 0.1% 64.9%, 17.9% 100%, 27.6% 76.8%, 76.1% 97.7%, 74.1% 44.1%)'}}></div>
        </div>
        <Header />
      </div>

      <main className="container mx-auto p-4 sm:p-6 md:p-8 -mt-24">
        <div className="max-w-4xl mx-auto mb-8 space-y-8">
          <TextInput
            label="Text to Check"
            placeholder="Paste the text you want to check for plagiarism here..."
            value={textToCheck}
            onValueChange={setTextToCheck}
            id="textToCheck"
            wordLimit={WORD_LIMIT}
          />
          <TextInput
            label="Original Text"
            placeholder="Paste the text you want to compare against here..."
            value={originalText}
            onValueChange={setOriginalText}
            id="originalText"
            wordLimit={WORD_LIMIT}
          />
        </div>

        <div className="text-center mb-8">
          <button
            onClick={handleCheckPlagiarism}
            disabled={isLoading}
            className="inline-flex items-center justify-center px-8 py-4 bg-brand-blue hover:bg-blue-800 text-white font-bold rounded-lg shadow-lg transition-all duration-300 ease-in-out transform hover:scale-105 disabled:bg-gray-400 disabled:cursor-not-allowed disabled:scale-100"
          >
            {isLoading ? (
              <>
                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Analyzing...
              </>
            ) : (
             <>
                <SparklesIcon className="w-6 h-6 mr-2" />
                Check for Plagiarism
              </>
            )}
          </button>
        </div>

        <ResultCard
          isLoading={isLoading}
          result={result}
          error={error}
          onParaphrase={handleParaphrase}
          isParaphrasing={isParaphrasing}
          paraphrasedText={paraphrasedText}
          paraphraseError={paraphraseError}
        />
      </main>
      
      <footer className="text-center p-4 text-gray-500 text-sm mt-8">
        <p>&copy; {new Date().getFullYear()} Sentop Solution Limited. All Rights Reserved.</p>
        <p className="mt-1">Powered by Gemini API. Designed for educational purposes.</p>
      </footer>
    </div>
  );
};

export default App;
