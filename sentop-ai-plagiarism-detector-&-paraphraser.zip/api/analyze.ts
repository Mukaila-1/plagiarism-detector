import { GoogleGenAI, Type } from "@google/genai";
import type { PlagiarismResult, Source } from '../src/types';

// This is a serverless function. It will be executed in a Node.js environment.
// The API_KEY is securely accessed from environment variables on the server.
if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// This function acts as the single entry point for all API requests from the frontend.
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { action } = body;

    if (action === 'plagiarism') {
      const { textToCheck, originalText } = body;
      const result = await handlePlagiarismCheck(textToCheck, originalText);
      return new Response(JSON.stringify(result), {
        status: 200,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    if (action === 'paraphrase') {
      const { text } = body;
      const paraphrasedText = await handleParaphrasing(text);
      return new Response(JSON.stringify({ paraphrasedText }), {
        status: 200,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    return new Response(JSON.stringify({ message: 'Invalid action' }), { status: 400 });
  } catch (error) {
    console.error("Error in serverless function:", error);
    const errorMessage = error instanceof Error ? error.message : "An unexpected error occurred.";
    return new Response(JSON.stringify({ message: errorMessage }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }
}

async function handlePlagiarismCheck(textToCheck: string, originalText?: string): Promise<PlagiarismResult> {
  const isDirectComparison = originalText && originalText.trim().length > 0;

  const prompt = isDirectComparison
    ? `
    As an expert in academic integrity and plagiarism detection, your task is to compare the "Text to Check" against the "Original Text".

    **Original Text:**
    ---
    ${originalText}
    ---

    **Text to Check:**
    ---
    ${textToCheck}
    ---

    Provide a plagiarism score (an integer between 0 and 100) and a detailed analysis. The analysis should highlight specific areas of concern, compare phrasing and structure between the two texts, and offer constructive feedback.
  `
    : `
    As an expert in academic integrity and plagiarism detection, your task is to analyze the following text for plagiarism against publicly available online sources using your search capabilities.

    **Text to Check:**
    ---
    ${textToCheck}
    ---

    Provide a plagiarism score and a detailed analysis. The score should be an integer between 0 and 100, where 0 indicates complete originality and 100 indicates a direct copy from an online source. The analysis should highlight specific areas of concern, compare phrasing and structure with online sources, and offer constructive feedback.

    IMPORTANT: You MUST return your findings as a single JSON object, and nothing else. The JSON object must have two keys: "score" (an integer) and "analysis" (a string). Do not wrap the JSON in markdown backticks or any other formatting.
  `;

  const config = isDirectComparison
    ? {
        temperature: 0.2,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            score: { type: Type.INTEGER },
            analysis: { type: Type.STRING },
          },
          required: ["score", "analysis"],
        },
      }
    : { tools: [{ googleSearch: {} }], temperature: 0.2 };

  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: prompt,
    config,
  });

  let sources: Source[] = [];
  if (!isDirectComparison) {
    const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
    sources =
      groundingChunks
        ?.map((chunk: any) => ({
          title: chunk.web?.title || "Unknown Title",
          uri: chunk.web?.uri || "#",
        }))
        .filter((source: any) => source.uri !== "#")
        .filter(
          (source, index, self) =>
            index === self.findIndex((s) => s.uri === source.uri)
        ) || [];
  }

  const responseText = response.text.trim();
  let parsedResult: Omit<PlagiarismResult, "sources">;

  try {
    if (isDirectComparison) {
      // With responseSchema, the text should be a valid JSON string.
      parsedResult = JSON.parse(responseText);
    } else {
      // For web search, we need to be more defensive.
      const jsonString = responseText
        .replace(/^```json\n?/, "")
        .replace(/\n?```$/, "");
      if (!jsonString) {
        throw new Error("AI returned an empty response for web search analysis.");
      }
      parsedResult = JSON.parse(jsonString);
    }
  } catch (parseError) {
    console.error("Failed to parse JSON response from AI:", responseText);
    throw new Error("The AI returned a response in an unexpected format. Please try again.");
  }


  if (
    typeof parsedResult.score !== "number" ||
    typeof parsedResult.analysis !== "string"
  ) {
    throw new Error("Invalid response format from API.");
  }

  return { ...parsedResult, sources };
}


async function handleParaphrasing(text: string): Promise<string> {
    const prompt = `
    As an expert academic writer, your task is to paraphrase the following text.
    Rewrite it to be completely original, ensuring the core meaning is preserved.
    Improve clarity, tone, and style for an academic audience.
    IMPORTANT: You MUST return ONLY the paraphrased text, and nothing else. Do not add any introductory phrases like "Here is the paraphrased text:".

    **Text to Paraphrase:**
    ---
    ${text}
    ---
  `;

  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: prompt,
    config: { temperature: 0.7 },
  });

  const paraphrased = response.text.trim();
  if (!paraphrased) {
      throw new Error("The AI returned an empty response for paraphrasing.");
  }
  return paraphrased;
}